from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.http import HttpResponseRedirect,HttpResponse
from members.forms import UserCreateForm, AuthenticatForm, PasswordChangingForm, PasswordResetingForm
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash

from django.conf import settings
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import BadHeaderError, send_mail
from django.db.models.query_utils import Q
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode

def login_user (request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = AuthenticatForm(request=request, data=request.POST)
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('/')
            else:
                messages.success(request,('There Was An Error Logging In, Please Try Again'))
                return redirect('login')
        form = AuthenticatForm()
        context = {'form': form }
        return render(request, 'registration/login.html', context)
    else:
        return redirect('/')
    
@login_required
def logout_user (request):
    logout(request)
    return redirect('/')

def register_user (request):
    if request.method == 'POST':
        form = UserCreateForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('/')
    form = UserCreateForm()
    context = {'form': form }
    return render(request,'registration/register_user.html', context)

@login_required
def password_change_user(request):
    if request.method == 'POST':
        form = PasswordChangingForm(request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user) # dont logout the user.
            return redirect('password_change_done')
    else:
        form = PasswordChangingForm(request.user)
    context = {'form': form }
    return render(request,'registration/password_change.html', context)


def password_reset_user(request):
    if request.method == "POST":
        domain = request.headers['Host']
        form = PasswordResetingForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data['email']
            users = User.objects.filter(Q(email=data))
            if users.exists():
                for user in users:
                    subject = "Password Reset Requested"
                    email_template_name = "registration/password_reset_email.txt"
                    c = {
                        "email": user.email,
                        'domain': 'http://127.0.0.1:8000',
                        'site_name': 'hivasite',
                        "uid": urlsafe_base64_encode(force_bytes(user.pk)),
                        "user": user,
                        'token': default_token_generator.make_token(user),
                        'protocol': 'http',
                    }
                    email = render_to_string(email_template_name, c)
                    try:
                        send_mail(subject, email, settings.EMAIL_HOST_USER, [user.email], fail_silently=False)
                    except BadHeaderError:    
                        return HttpResponse('Invalid header found.')
                    return redirect("password_reset_done")
    else:
        form = PasswordResetingForm()
    context={"form": form}
    return render(request, 'registration/password_reset.html',context)






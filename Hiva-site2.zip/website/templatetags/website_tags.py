from django import template
from blog.models import Post
register = template.Library()

@register.inclusion_tag('website/website_latest_post.html')
def websitelatestposts(arg=6):
    posts = Post.objects.filter(status=1).order_by('-published_date')[:arg]
    return {'posts':posts} 